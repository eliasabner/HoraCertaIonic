import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-despertar',
  templateUrl: './despertar.page.html',
  styleUrls: ['./despertar.page.scss'],
})
export class DespertarPage implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
